package com.atguigu.team.domain;

public interface Equipment {
	
	String getDescription();
}
